#ifndef INPUT_H
#define INPUT_H

#include "defs.h"

// 사용자 입력을 처리하는 핵심 함수
void handle_events(void);

#endif